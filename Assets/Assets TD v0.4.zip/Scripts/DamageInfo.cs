using UnityEngine;
using System.Collections;

public class DamageInfo : IPooledObject {
	public float Value;
	public FactionType SourceFactionType;
}
