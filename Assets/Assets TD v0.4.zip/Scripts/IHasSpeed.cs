﻿using UnityEngine;
using System.Collections;

public interface IHasSpeed {
	float Speed { get; set; }
}
