﻿using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using System.Collections;
using System.Linq;
using System.IO;

[CustomEditor(typeof(UnitManager))]
public class UnitManagerEditor : Editor {
	public override void OnInspectorGUI () {
		base.OnInspectorGUI ();


	}
}
