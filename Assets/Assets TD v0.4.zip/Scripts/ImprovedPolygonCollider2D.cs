﻿using UnityEngine;
using System.Collections;

[RequireComponent(typeof(PolygonCollider2D))]
public class ImprovedPolygonCollider2D : MonoBehaviour {
}
