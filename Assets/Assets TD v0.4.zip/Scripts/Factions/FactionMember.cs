﻿using UnityEngine;
using System.Collections;

public class FactionMember : MonoBehaviour {
	public FactionType FactionType;
}
