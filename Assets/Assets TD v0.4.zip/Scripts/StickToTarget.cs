﻿using UnityEngine;
using System.Collections;

/// <summary>
/// Let's a given object stay always on top of another object
/// </summary>
public class StickToTarget : MonoBehaviour {
	// TODO
}