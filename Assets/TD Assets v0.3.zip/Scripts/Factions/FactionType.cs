﻿using UnityEngine;
using System.Collections;

public enum FactionType {
	None = 0,		// default
	Player,
	Enemy
}
