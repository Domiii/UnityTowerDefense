﻿using UnityEngine;
using System.Collections;

public class QuestionSet : ScriptableObject {
	public QuizQuestion[] Questions = new QuizQuestion[0];
}
