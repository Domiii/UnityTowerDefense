﻿using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using System.Collections;

[CustomEditor(typeof(BuyUnitButton))]
public class BuyUnitButtonEditor : Editor {
//	public string[] options = new string[] {"Cube", "Sphere", "Plane"};
//	public int index = 0;
//
//	public override void OnInspectorGUI () {
//		DrawDefaultInspector();
//
//		var lastIndex = index;
//		index = EditorGUILayout.Popup(index, options);
//		if (lastIndex != index) {
//			Debug.Log(index);
//		}
//
//		EditorUtility.SetDirty(target);
//	}
//
//	// Use this for initialization
//	void OnEnable  () {
//		
//	}
}
