using UnityEngine;
using System.Collections;

public class EnemyFaction : Faction {
	public EnemyFaction() : base(FactionType.Enemy) {
	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
