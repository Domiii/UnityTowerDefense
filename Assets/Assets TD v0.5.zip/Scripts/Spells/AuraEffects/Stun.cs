﻿using UnityEngine;
using System.Collections;

namespace Spells {
	[CustomScriptableObjectAttribute("Damage")]
	public class Stun : AuraEffect {

	}
}